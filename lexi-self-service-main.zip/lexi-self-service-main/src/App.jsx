import { createHashRouter, RouterProvider } from 'react-router-dom'
import { Approvals, Audiences, Calendar, Campaigns, Error, HomeLayout, Landing, NewCampaign, PageFallback, Programs, Settings, Templates } from './pages'
import {action as ProgramsAction} from './pages/Programs'
import {action as CampaignsAction} from './pages/Campaigns'
import { loader as NewCampaignLoader } from './pages/NewCampaign'
import {action as NewCampaignAction} from './pages/NewCampaign'

const router = createHashRouter([
  {
    path: '/',
    element: <HomeLayout />,
    errorElement: <Error />,
    hydrateFallbackElement: <PageFallback />,
    children: [
      {
        index: true,
        element: <Landing />
      },
      {
        path: '/programs',
        element: <Programs />,
        action: ProgramsAction
      },
      {
        path: '/campaigns',
        element: <Campaigns />,
        action: CampaignsAction
      },
      {
        path: '/campaigns/:id/edit',
        element: <NewCampaign />,
        loader: NewCampaignLoader,
        action: NewCampaignAction
      },
      {
        path: '/audiences',
        element: <Audiences />
      },
      {
        path: '/templates',
        element: <Templates />
      },
      {
        path: '/calendar',
        element: <Calendar />
      },
      {
        path: '/approvals',
        element: <Approvals />
      },
      {
        path: '/settings',
        element: <Settings />
      }
    ]
  }
])

function App() {

  return <RouterProvider router={router} />
}

export default App
