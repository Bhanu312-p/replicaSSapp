import { IoCalendarOutline, IoHome } from "react-icons/io5";
import { MdOutlineCampaign, MdOutlineRocketLaunch, MdOutlineSettings } from "react-icons/md";
import { BsPeople } from "react-icons/bs";
import { HiOutlineTemplate } from "react-icons/hi";
import { FaUserCheck } from "react-icons/fa6";

export const navLinks = [
    {
        path: '/',
        text: 'Home',
        icn: IoHome
    },
    {
        path: '/programs',
        text: 'Programs',
        icn: MdOutlineRocketLaunch
    },
    {
        path: '/campaigns',
        text: 'Campaigns',
        icn: MdOutlineCampaign
    },
    {
        path: '/audiences',
        text: 'Audiences',
        icn: BsPeople
    },
    {
        path: '/templates',
        text: 'Templates',
        icn: HiOutlineTemplate
    },
    {
        path: '/calendar',
        text: 'Calendar',
        icn: IoCalendarOutline
    },
    {
        path: '/approvals',
        text: 'Approvals',
        icn: FaUserCheck
    },
    {
        path: '/settings',
        text: 'Settings',
        icn: MdOutlineSettings
    }
]
