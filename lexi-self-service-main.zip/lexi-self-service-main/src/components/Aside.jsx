import React from 'react'
import { Link, NavLink } from 'react-router-dom'
import { navLinks } from '../NavLinks';
import logoImg from '../assets/logo.png'
import logoImgSmall from '../assets/logo-icon.png'

const Aside = ({collapsed}) => {
  return (
    <aside className={`theme-bg min-h-screen transition-[width] z-50 duration-300 ease-out ${collapsed ? 'w-20' : 'w-64'} fixed`}>
      <div className='aside-header text-white p-2 text-center'>
        <Link to='/' className='text-xl transition duration-300 ease-out'>
          {collapsed ? <img src={logoImgSmall} className='w-8 ml-auto mr-auto' title='Learning Communications' /> : <img src={logoImg} style={{width: '172px'}} className='ml-auto mr-auto' title='Learning Communications' />}  
        </Link>
      </div>
      <ul className='menu w-full h-[calc(100%-65px)] overflow-y-auto pt-4'>
        {
            navLinks.map(link => {
                return <li key={link.text}>
                    <NavLink title={link.text} to={link.path} className={({isActive}) => {
                       return `${isActive ? 'text-white font-semibold bg-purple border-l-white border-l-4' : 'text-gray-300 border-l-4 border-l-transparent'} h-12 px-5 py-3`
                    }}>
                        <span><link.icn className='text-lg' /></span>
                        {!collapsed && <span className='ml-2'>{link.text}</span>}
                    </NavLink>
                </li>
            })
        }
        
      </ul>
    </aside>
  )
}

export default Aside
