import React from 'react'

const Footer = ({footerExtend}) => {
  return (
    <footer className={`${footerExtend ? 'ps-20' : 'ps-64'} footer sm:footer-horizontal footer-center bg-base-200 text-base-content p-2 transition-[padding] duration-300 ease-out`} style={{border: '1px solid #e2e2e2', height: '40px'}}>
        <aside>
            <p className='ft-size12'>Copyright © {new Date().getFullYear()} - Microsoft. All rights reserved</p>
        </aside>
    </footer>
  )
}

export default Footer
