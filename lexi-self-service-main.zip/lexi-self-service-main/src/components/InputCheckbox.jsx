import React from 'react'

const InputCheckbox = ({name, text, defaultChecked, size}) => {
  return (
    <label className='flex gap-2 items-center'>
        <input type='checkbox' name={name} id={name} defaultChecked={defaultChecked} className={`checkbox checkbox-secondary checked:bg-[#8661c5] checked:border-[#8661c5] ${size}`} />
        <div htmlFor={name} className='label cursor-pointer'>
            <span className='label-text ft-size14 text-gray-700 font-semibold'>{text}</span>
        </div>
    </label>
  )
}

export default InputCheckbox
