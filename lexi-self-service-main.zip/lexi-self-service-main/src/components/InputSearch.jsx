import React from 'react'

const InputSearch = ({Icon, text, name, placeholder, defaultValue}) => {
  return (
    <label className="w-full">
        <div className="label">
            { Icon && <Icon className='text-gray-500' />}
            <span className="label-text ft-size14 text-gray-700 font-semibold">{text}</span>
        </div>
        <div className="join w-full">
            <div className="join-item input input-bordered flex items-center gap-2 grow pr-2">
            <span className="opacity-60">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M21 21l-4.35-4.35M11 19a8 8 0 1 1 0-16 8 8 0 0 1 0 16Z" />
                </svg>
            </span>
            <input
                type="text"
                className="grow outline-none bg-transparent"
                placeholder={placeholder}
                name={name}
                defaultValue={defaultValue}
            />
            </div>
        </div>
    </label>
  )
}

export default InputSearch
