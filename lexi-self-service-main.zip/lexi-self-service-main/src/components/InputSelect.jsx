import React from 'react'

const InputSelect = ({Icon, text, size, name, list, defaultValue, required}) => {
  return (
    <label className="w-full">
        <div className="label">
            { Icon && <Icon className='text-gray-500' />}
            <span className={`label-text ${size === 'select-sm' ? 'ft-size12' : 'ft-size14'} text-gray-700 font-semibold`}>{text}</span>
        </div>
        <select name={name} id={name} defaultValue={defaultValue} className={`select select-bordered ${size === 'select-sm' ? 'ft-size12 select-sm' : 'ft-size14'}`} required={required}>
            {
                list.map(item => <option key={item} value={item}>{item}</option>)
            }
        </select>
    </label>
  )
}

export default InputSelect
