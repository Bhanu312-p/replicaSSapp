import React from 'react'

const InputText = ({Icon, text, type, name, size, placeholder, defaultValue, required}) => {
  return (
    <label className="w-full">
        <div className="label">
            { Icon && <Icon className='text-gray-500' />}
            <span className={`label-text ${size === 'input-sm' ? 'ft-size12' : 'ft-size14'}  text-gray-700 font-semibold`}>{text}</span>
            {required && <span className="text-red-500">*</span>}
        </div>
        <input
                type={type}
                className={`input w-full grow outline-none bg-white ${size === 'input-sm' ? 'input-sm' : 'ft-size14'}`}
                placeholder={placeholder}
                name={name}
                defaultValue={defaultValue}
                required={required}
            />
    </label>
  )
}

export default InputText
