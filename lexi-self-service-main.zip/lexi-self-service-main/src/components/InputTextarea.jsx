import React from 'react'

const InputTextarea = ({Icon, text, name, size, placeholder, defaultValue, required}) => {
  return (
    <label className="w-full">
        <div className="label block">
            { Icon && <Icon className='text-gray-500' />}
            <span className={`label-text ${size === 'input-sm' ? 'ft-size12' : 'ft-size14'}  text-gray-700 font-semibold`}>{text}</span>
            {required && <span className="text-red-500">*</span>}
        </div>
        <textarea
                className={`textarea w-full grow outline-none ${size === 'input-sm' ? 'ft-size12' : 'ft-size14'}`}
                placeholder={placeholder}
                name={name}
                defaultValue={defaultValue}
                required={required}
            >
        </textarea>
    </label>
  )
}

export default InputTextarea
