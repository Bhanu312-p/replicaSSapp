import React from 'react'
import { MdClose } from 'react-icons/md'
import { Link, NavLink } from 'react-router-dom'

const Navbar = ({toggleNav, navExtend}) => {
  return (
    <div className={`${navExtend ? 'ps-20' : 'ps-64'} navbar z-20 fixed bg-base-100 shadow-md shadow-gray-200 transition-[padding] duration-300 ease-out`}>
        <div className="navbar-start">
          {/* <div className="dropdown">
            <div tabIndex={0} role="button" className="btn btn-ghost md:hidden">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h8m-8 6h16" /> </svg>
            </div>
            <ul
              tabIndex={0}
              className="menu menu-sm dropdown-content bg-base-100 rounded-box z-1 mt-3 w-52 p-2 shadow">
              <li><NavLink to=''>Link 1</NavLink></li>
              <li><NavLink to=''>Link 2</NavLink></li>
              <li><NavLink to=''>Link 3</NavLink></li>
            </ul>
          </div> */}
          
          <div className="flex-none">
            <button onClick={toggleNav} className="btn btn-square btn-ghost mr-2">
              {navExtend ? <MdClose /> : <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h8m-8 6h16" /> </svg> }
            </button>
          </div>
          <p className="text-gray-700 font-semibold" style={{fontSize: '16px'}}>
            {/* Campaign Self-Service Portal */}
          </p>
        </div>
        <div className="navbar-end hidden md:flex">
            <button className='rounded-2xl px-4 py-2 text-sm shadow items-center justify-center gap-2 transition hover:bg-gray-50 hidden md:inline-flex mr-2'>Feedback</button>
            <button className='rounded-2xl px-4 py-2 text-sm shadow items-center justify-center gap-2 transition hover:bg-gray-50 hidden md:inline-flex'>Support</button>
        </div>
    </div>
  )
}

export default Navbar
