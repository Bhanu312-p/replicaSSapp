import React, { useState } from 'react'
import { MdContentPasteSearch, } from 'react-icons/md';
import { Form, Link } from 'react-router-dom';
import { InputCheckbox, InputSearch, InputSelect } from '../components';
import { GrStatusGood } from 'react-icons/gr';
import { LiaToolsSolid } from 'react-icons/lia';
import { FaBarsProgress } from 'react-icons/fa6';

const approvalsData = [
  {
    id: "AP-3001",
    itemName: "FY25 Q2 Manager Essentials – Launch",
    itemId: "CM-24091",
    type: "Campaign",
    requestedBy: "Gabe Long",
    owner: "LEXI Programs",
    currentApprover: "Ops – Campaign Desk",
    status: "In review",
    submittedOn: "2025-10-28T10:15:00Z",
    neededBy: "2025-11-05T00:00:00Z",
    campaignsImpact: 1,
    riskFlag: "Standard",
  },
  {
    id: "AP-3002",
    itemName: "Security Compliance – Reminder 1 (Email)",
    itemId: "TM-1002",
    type: "Email template",
    requestedBy: "Priya Desai",
    owner: "Security Awareness",
    currentApprover: "Brand & Legal",
    status: "Pending triage",
    submittedOn: "2025-10-30T09:40:00Z",
    neededBy: "2025-11-07T00:00:00Z",
    campaignsImpact: 3,
    riskFlag: "Elevated",
  },
  {
    id: "AP-3003",
    itemName: "New Hires – Last 30 Days audience exception",
    itemId: "AU-24003",
    type: "Audience exception",
    requestedBy: "Marco Alvarez",
    owner: "Sales Enablement",
    currentApprover: "Data & Privacy",
    status: "In review",
    submittedOn: "2025-10-27T14:05:00Z",
    neededBy: "2025-11-03T00:00:00Z",
    campaignsImpact: 2,
    riskFlag: "Elevated",
  },
  {
    id: "AP-3004",
    itemName: "Skilling Month-in-Review (Email template)",
    itemId: "TM-1003",
    type: "Email template",
    requestedBy: "Jenna Park",
    owner: "Skilling Programs",
    currentApprover: "Ops – Content",
    status: "Approved",
    submittedOn: "2025-10-18T09:00:00Z",
    neededBy: "2025-10-20T00:00:00Z",
    campaignsImpact: 3,
    riskFlag: "Standard",
  },
  {
    id: "AP-3005",
    itemName: "Security Champions – Welcome",
    itemId: "TM-1005",
    type: "Email template",
    requestedBy: "Priya Desai",
    owner: "Security Awareness",
    currentApprover: "Ops – Campaign Desk",
    status: "Changes requested",
    submittedOn: "2025-10-19T12:20:00Z",
    neededBy: "2025-10-25T00:00:00Z",
    campaignsImpact: 1,
    riskFlag: "Standard",
  },
];

const statusList = ['All statuses', 'Pending triage', 'In review', 'Approved', 'Changes requested']
const requestTypes = ['All request types', 'Campaign', 'Email template', 'Audience exception']

const statusOptions = [
  { id: 'all', label: 'All' },
  { id: 'active', label: 'Active' },
  { id: 'completed', label: 'Completed' },
];

const getBadgeClass = (status) => {
  switch (status) {
    case 'In review':
      return 'bg-blue-100 text-blue-700';
    case 'Approved':
      return 'bg-green-100 text-green-700';
    case 'Pending triage':
      return 'bg-red-100 text-red-700';
    case 'Changes requested':
      return 'bg-teal-100 text-teal-700';
    default:
      return 'bg-green-100 text-green-700';
  }
};

const Approvals = () => {
  const [approvalStatus, setapprovalStatus] = useState('all');
  const baseBtn = 'rounded-full cursor-pointer px-3 py-1 ft-size12 font-medium transition focus:outline-none focus:ring focus:ring-blue-300';
  const passive = 'bg-gray-100 cursor-pointer text-gray-700 hover:bg-gray-200';
  const active = 'bg-purple cursor-pointer text-white shadow hover:bg-blue-700';
  return (
    <>
    <div className='mb-5'>
      <h2 className='ft-size24 font-semibold mb-1'>Approvals</h2>
      <p>Central queue for campaign, template, and audience exception approvals. Optimized for “what needs action from whom, by when”.</p>
    </div>

    <div className='bg-base-100 rounded-box shadow-md mb-5'>
      <Form method='get' className='p-4'>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 justify-between items-end mb-2">
          <div>
            <InputSearch text='Search' name='search' placeholder='Search...' Icon={MdContentPasteSearch} />
          </div>
          <InputSelect text='Status' name='status' list={statusList} Icon={GrStatusGood} />
          <InputSelect text='Request type' name='requests' list={requestTypes} Icon={LiaToolsSolid}/>
        </div>

        <div className="flex gap-7 items-end">
          <div className="">
            <div className="label">
              <FaBarsProgress className='text-gray-500' />
              <span className={`label-text ft-size14 text-gray-700 font-semibold`}>State</span>
            </div>
            <div>
            {statusOptions.map(opt => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setapprovalStatus(opt.id)}
                className={`${baseBtn} ${approvalStatus === opt.id ? active : passive}`}
              >
                {opt.label}
              </button>
            ))}
            </div>
          </div>
          {/* Hidden field so selection is submitted with the form */}
          <input type="hidden" name="usage" value={approvalStatus} />

          <div className=''>
            <InputCheckbox className='font-normal' text='Only show my queue' name='myQueue' />
          </div>
          <div className=''>
            <InputCheckbox className='font-normal' text='Only show my requests' name='showMyRequests' />
          </div>
          
          <div className="flex gap-2 ml-auto">
            <button type="button" className="btn shadow-sm shadow-gray-500/50 btn-purple">
              Apply filters
            </button>
            <button type="button" className="btn btn-ghost">
              Reset
            </button>
          </div>
        </div>

          
      </Form>
    </div>

    <div className='bg-base-100 rounded-box shadow-md p-4 mb-5'>
      <div className="overflow-x-auto w-auto max-w-full">
        <table className="table table-sm table-zebra table-auto min-w-full">
          {/* head */}
          <thead>
            <tr className='bg-lightest-purple ft-size12'>
              <th>Request ID</th>
              <th>Item</th>
              <th>Item ID</th>
              <th>Request type</th>
              <th>Requested by</th>
              <th>Owner</th>
              <th>Current approver</th>
              <th>Submitted on</th>
              <th>Needed by</th>
              <th>Status</th>
              <th>Impact</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {
              approvalsData.map(rowData => {
                const {id, itemName, itemId, type, requestedBy, owner, currentApprover, status, submittedOn, neededBy, campaignsImpact, riskFlag} = rowData
                return (
                <tr key={id}>
                  <td>{id}</td>
                  <td className='font-semibold'><Link className='hover:underline'>{itemName}</Link></td>
                  <td>{itemId}</td>
                  <td>{type}</td>
                  <td>{requestedBy}</td>
                  <td>{owner}</td>
                  <td>{currentApprover}</td>
                  <td>{submittedOn}</td>
                  <td>{neededBy}</td>
                  <td><div className={`rounded-2xl inline-block px-2 py-1 text-xs ${getBadgeClass(status)}`}>{status}</div></td>
                  <td>{campaignsImpact}</td>
                  <td>{ riskFlag === 'Elevated' && <div className='rounded-2xl inline-block px-2 py-1 text-xs bg-red-100 text-red-700'>{riskFlag}</div> }</td>
                </tr>
                )
              })
            }
          </tbody>
        </table>
      </div>
    </div>
    </>
  )
}

export default Approvals
