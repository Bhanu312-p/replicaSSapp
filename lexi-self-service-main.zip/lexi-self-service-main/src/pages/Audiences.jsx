import React, { useState } from 'react'
import { Form, Link } from 'react-router-dom'
import { InputCheckbox, InputSearch, InputSelect, InputToggle } from '../components'
import { MdContentPasteSearch, MdOutlineCampaign } from 'react-icons/md'
import { IoKeyOutline } from 'react-icons/io5'
import { GoPeople } from 'react-icons/go'
import { PiPlugsConnectedFill } from 'react-icons/pi'

const audienceData = [
  {
    id: "AU-24001",
    name: "People Managers – Worldwide",
    owner: "Gabe Long",
    audienceCount: 18442,
    source: "Audience Segmentation Report",
    lastModified: "2025-10-28T11:20:00Z",
    campaignsUsing: 3,
  },
  {
    id: "AU-24002",
    name: "Security Champions – Pilot Wave",
    owner: "Priya Desai",
    audienceCount: 6120,
    source: "Audience Segmentation Report",
    lastModified: "2025-10-30T08:05:00Z",
    campaignsUsing: 1,
  },
  {
    id: "AU-24003",
    name: "New Hires – Last 30 Days",
    owner: "Marco Alvarez",
    audienceCount: 1220,
    source: "Audience Segmentation Report",
    lastModified: "2025-10-29T15:45:00Z",
    campaignsUsing: 2,
  },
  {
    id: "AU-24004",
    name: "Azure Sellers – AMER",
    owner: "Jenna Park",
    audienceCount: 6200,
    source: "Audience Segmentation Report",
    lastModified: "2025-10-20T09:10:00Z",
    campaignsUsing: 0,
  },
  {
    id: "AU-24005",
    name: "Skilling Month-in-Review Test Cohort",
    owner: "Gabe Long",
    audienceCount: 250,
    source: "Audience Segmentation Report",
    lastModified: "2025-10-18T13:32:00Z",
    campaignsUsing: 0,
  },
]

const audienceSizeOptions = ['All sizes', '< 1000', '1000 - 10000', '> 10000']
const campaignConnectionOptions = ['All audiences', 'Used in campaigns', 'Not yet used']
const connectionOptions = [
  { id: 'all', label: 'All' },
  { id: 'connected', label: 'Connected' },
  { id: 'unconnected', label: 'Not connected' },
];

const Audiences = () => {
  const [connectionStatus, setconnectionStatus] = useState('all');
  const baseBtn = 'rounded-full cursor-pointer px-3 py-1 ft-size12 font-medium transition focus:outline-none focus:ring focus:ring-blue-300';
  const passive = 'bg-gray-100 cursor-pointer text-gray-700 hover:bg-gray-200';
  const active = 'bg-purple cursor-pointer text-white shadow hover:bg-blue-700';
  return (
    <>
    <div className='mb-5'>
      <h2 className='ft-size24 font-semibold mb-1'>Audiences</h2>
      <p>Audiences are sourced from the Audience Segmentation Report today. Manual uploads will be enabled in a future release.</p>
    </div>

    <div className='bg-base-100 rounded-box shadow-md mb-5'>
      <Form method='get' className='p-4'>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 justify-between items-end mb-2">
          <div>
            <InputSearch text='Search' name='search' placeholder='Search...' Icon={MdContentPasteSearch} />
          </div>
          <InputSelect text='Audience size' name='audienceSize' list={audienceSizeOptions} Icon={GoPeople} />
          <InputSelect text='Campaign connections' name='campaignConnections' list={campaignConnectionOptions} Icon={MdOutlineCampaign}/>
        </div>

        <div className="grid grid-cols-3 gap-5 items-end">
          <div className="">
            <div className="label">
              <PiPlugsConnectedFill className='text-gray-500' />
              <span className={`label-text ft-size14 text-gray-700 font-semibold`}>Connection status</span>
            </div>
            <div>
            {connectionOptions.map(opt => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setconnectionStatus(opt.id)}
                className={`${baseBtn} ${connectionStatus === opt.id ? active : passive}`}
              >
                {opt.label}
              </button>
            ))}
            </div>
          </div>
          {/* Hidden field so selection is submitted with the form */}
          <input type="hidden" name="usage" value={connectionStatus} />

          <div className=''>
            <div className="label">
              <IoKeyOutline className='text-gray-500' />
              <span className={`label-text ft-size14 text-gray-700 font-semibold`}>Ownership</span>
            </div>
            <InputToggle className='font-normal' text='Only show audiences I own' name='myAudiences' />
          </div>
          
          <div className="flex gap-2 ml-auto">
            <button type="button" className="btn shadow-sm shadow-gray-500/50 btn-purple">
              Apply filters
            </button>
            <button type="button" className="btn btn-ghost">
              Reset
            </button>
          </div>
        </div>

          
      </Form>
    </div>

    <div className='bg-base-100 rounded-box shadow-md p-4 mb-5'>
      <div className="overflow-x-auto w-auto max-w-full">
        <table className="table table-zebra table-auto min-w-full">
          {/* head */}
          <thead>
            <tr className='bg-lightest-purple'>
              <th>ID</th>
              <th>Name</th>
              <th>Audience count</th>
              <th>Owner</th>
              <th>Source</th>
              <th>Last modified</th>
              <th>Used in campaigns</th>
            </tr>
          </thead>
          <tbody>
            {
              audienceData.map(rowData => {
                const {id, name, audienceCount, owner, source, lastModified, campaignsUsing} = rowData
                return (
                <tr key={id}>
                  <td>{id}</td>
                  <td className='font-semibold'><Link className='hover:underline'>{name}</Link></td>
                  <td>{audienceCount}</td>
                  <td>{owner}</td>
                  <td>{source}</td>
                  <td>{lastModified}</td>
                  <td>{campaignsUsing}</td>
                </tr>
                )
              })
            }
          </tbody>
        </table>
      </div>
    </div>
    </>
  )
}

export default Audiences
