import React from 'react'

const Calendar = () => {
  return (
    <div>
      <h2 className='ft-size24 font-semibold mb-1'>Calendar</h2>
      <p>See all scheduled and draft learning comms by send date and drill into details.</p>
    </div>
  )
}

export default Calendar
