import React, { useState } from 'react'
import { BsPeopleFill } from 'react-icons/bs';
import { MdContentPasteSearch, MdEdit, MdMediation, MdOutlineCampaign, MdOutlineEmail } from 'react-icons/md';
import { PiMicrosoftTeamsLogoFill, PiPlugsConnectedFill } from 'react-icons/pi';
import { Form, Link, useNavigate, redirect } from 'react-router-dom'
import { InputCheckbox, InputSearch, InputSelect, InputToggle, InputText, InputTextarea } from '../components';
import { IoKeyOutline } from 'react-icons/io5';
import { GrStatusGood } from 'react-icons/gr';
import { RiProgress3Line } from 'react-icons/ri';

const campaignsData = [
  {
    id: "CM-24091",
    name: "FY25 Q2 Manager Essentials – Launch",
    owner: "Gabe Long",
    audienceCount: 18442,
    channel: "Email+Teams",
    status: "Active",
    lastModified: "2025-10-29T12:34:00Z",
    progress: 72,
    fiscalYearEnd: "2025-06-30T00:00:00Z",
    purpose:
      "Drive completion of Manager Essentials training for all people managers worldwide.",
    goLiveDate: "2025-01-15",
    endDate: "2025-06-30",
  },
  {
    id: "CM-24102",
    name: "Security Compliance Refresher – Reminder 1",
    owner: "Priya Desai",
    audienceCount: 62031,
    channel: "Email",
    status: "Scheduled",
    lastModified: "2025-10-30T09:10:00Z",
    progress: 0,
    fiscalYearEnd: "2025-06-30T00:00:00Z",
  },
  {
    id: "CM-24105",
    name: "AI Sales Play: Copilot Attach",
    owner: "Marco Alvarez",
    audienceCount: 12220,
    channel: "Teams",
    status: "Draft",
    lastModified: "2025-10-30T17:25:00Z",
    progress: 24,
    fiscalYearEnd: "2025-06-30T00:00:00Z",
  },
  {
    id: "CM-24106",
    name: "FY25 Skilling – Month-in-Review",
    owner: "Jenna Park",
    audienceCount: 44002,
    channel: "Email",
    status: "Completed",
    lastModified: "2025-10-20T15:02:00Z",
    progress: 100,
    fiscalYearEnd: "2025-06-30T00:00:00Z",
  },
  {
    id: "CM-24107",
    name: "Partner Attach – Pilot Wave 2",
    owner: "Samir Patel",
    audienceCount: 6120,
    channel: "Email+Teams",
    status: "Ops Processing",
    lastModified: "2025-10-28T11:00:00Z",
    progress: 56,
    fiscalYearEnd: "2025-06-30T00:00:00Z",
  },
]

const statusOptions = ['All Statuses', 'Draft', 'Ops Processing', 'Scheduled', 'Active', 'Completed', 'Cancelled', 'In governance' ]
const channelOptions = ['All channels', 'Email', 'Teams', 'Email+Teams']

const progressOptions = [
  { id: 'all', label: 'All' },
  { id: 'inflight', label: 'In-flight' },
  { id: 'completed', label: 'Completed' }
];

const getBadgeClass = (status) => {
  switch (status) {
    case 'Active':
      return 'bg-green-100 text-green-700';
    case 'Ops Processing':
      return 'bg-orange-100 text-orange-700';
    case 'Scheduled':
      return 'bg-blue-100 text-blue-700';
    case 'Draft':
      return 'bg-yellow-100 text-yellow-700';
    case 'Completed':
      return 'bg-teal-100 text-teal-700';
    case 'Cancelled':
      return 'bg-red-100 text-red-700';
    case 'In governance':
      return 'bg-gray-100 text-gray-700';
    default:
      return 'bg-green-100 text-green-700';
  }
};

const getChannelIcon = (channel) => {
  switch (channel) {
    case 'Teams':
      return <PiMicrosoftTeamsLogoFill title='Teams' className='ft-size18 text-gray-600' />;
    case 'Email':
      return <MdOutlineEmail  title='Email' className='ft-size18 text-gray-600' />;
    case 'Email+Teams':
      return <div className='flex'><MdOutlineEmail title='Email' className='ft-size18 text-gray-600' /> + <PiMicrosoftTeamsLogoFill title='Teams' className='ft-size18 text-gray-600' /></div>;
    default:
      return null;
  }
};

export const action = async({ request }) => {
  if (request.method === 'POST') {
    const formData = await request.formData();
    
    // Generate unique ID for campaign
    const campaignId = `CM-${Math.floor(Date.now()/1000)}-${Math.random().toString(36).slice(2,6).toUpperCase()}`;
    
    // Extract form data
    const payload = {
      id: campaignId,
      name: formData.get('campaignName') || '',
      purpose: formData.get('purpose') || '',
      goLiveDate: formData.get('goLiveDate') || '',
      endDate: formData.get('endDate') || '',
      audienceList: [],
      touchpoints: []
    };
    
    // TODO: Send to Dataverse endpoint when available
    // const response = await fetch('/api/dataverse/campaigns', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify(payload)
    // });
    
    console.log('Campaign payload:', payload);
    return redirect(`/campaigns/${campaignId}/edit`);
  }
  return null;
}

const Campaigns = () => {
  const navigate = useNavigate()
  const [progressActive, setProgressActive] = useState('all');
  const [isModalOpen, setIsModalOpen] = useState(false)
  
  const generateCampaignId = () => {
    return `CM-${Math.floor(Date.now()/1000)}-${Math.random().toString(36).slice(2,6).toUpperCase()}`
  }

  const computeFiscalEndDate = (goLive) => {
    if (!goLive) return ''
    try {
      const d = new Date(goLive)
      const year = d.getFullYear()
      const month = d.getMonth() + 1 // 1-12
      // fiscal year ends June 30. If go-live is in Jan-Jun => same year June 30, else next year June 30
      const endYear = month <= 6 ? year : year + 1
      return `${endYear}-06-30`
    } catch(e) {
      return ''
    }
  }
  const baseBtn = 'rounded-full cursor-pointer px-3 py-1 ft-size12 font-medium transition focus:outline-none focus:ring focus:ring-blue-300';
  const passive = 'bg-gray-100 cursor-pointer text-gray-700 hover:bg-gray-200';
  const active = 'bg-purple cursor-pointer text-white shadow hover:bg-blue-700';

  return (
    <>
    <div className='md:flex justify-between items-center pb-2 text-xs mb-5'>
      <div className="">
        <h2 className='ft-size24 font-semibold mb-1'>Campaigns</h2>
        <p>Build, schedule, and track multi-channel campaigns within the current fiscal year.</p>
      </div>
      <button onClick={() => setIsModalOpen(true)} className='md:text-end btn shadow-sm shadow-gray-500/50 btn-magenta'>+ New campaign</button>
    </div>

    {isModalOpen && (
      <div className='fixed inset-0 z-50 flex items-center justify-center'>
        <div className='absolute inset-0 bg-black/40' onClick={() => setIsModalOpen(false)}></div>
        <div className='relative w-[90%] max-w-2xl bg-white rounded-lg shadow-lg overflow-hidden'>
          <div className='flex items-center justify-between px-5 py-4 border-b border-gray-200'>
            <div>
              <h3 className='ft-size16 text-md font-semibold'>Create campaign container</h3>
              <p className='ft-size12 text-xs text-gray-600'>Define your campaign and fiscal boundary.</p>
            </div>
            <button onClick={() => setIsModalOpen(false)} className='text-gray-500 cursor-pointer hover:text-gray-700'>✕</button>
          </div>
          <Form method='post' className='p-5'>
            <div className='grid gap-3'>
              <InputText name='campaignName' text='Campaign name' placeholder='e.g. FY25 Manager Essentials – Global Launch' required={true} />
              <InputTextarea name='purpose' text='Purpose / goal' placeholder='e.g. Drive completion of Manager Essentials training for all people managers.' required={true} />
              <div className='grid grid-cols-2 gap-4'>
                <InputText type='date' name='goLiveDate' text='Estimated go-live date' required={true} />
                <InputText type='date' name='endDate' text='End date (derived)' />
              </div>
              <div className='text-sm text-gray-500 p-3 rounded'>
                <p className='ft-size12'>Learning programs target an initial audience with due dates (e.g. 60/90/120/180 days). New hires and new-to-role learners are handled via data-driven segments, but the container shouldn't extend past the current fiscal year without explicit approval.</p>
              </div>
              <div className='flex justify-end gap-3'>
                <button type='button' onClick={() => setIsModalOpen(false)} className='btn btn-ghost'>Cancel</button>
                <button type='submit' className='btn shadow-sm shadow-gray-500/50 btn-purple'>Continue</button>
              </div>
            </div>
          </Form>
        </div>
      </div>
    )}

    <div className='bg-base-100 rounded-box shadow-md mb-5'>
      <Form method='get' className='p-4'>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 justify-between items-end mb-2">
          <div>
            <InputSearch text='Search' name='search' placeholder='Search...' Icon={MdContentPasteSearch} />
          </div>
          <InputSelect text='Status' name='statusInput' list={statusOptions} Icon={GrStatusGood} />
          <InputSelect text='Channel' name='channelInput' list={channelOptions} Icon={MdMediation}/>
        </div>

        <div className="grid grid-cols-3 gap-5 items-end">
          <div className="">
            <div className="label">
              <RiProgress3Line className='text-gray-500' />
              <span className={`label-text ft-size14 text-gray-700 font-semibold`}>Progress</span>
            </div>
            <div>
            {progressOptions.map(opt => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setProgressActive(opt.id)}
                className={`${baseBtn} ${progressActive === opt.id ? active : passive}`}
              >
                {opt.label}
              </button>
            ))}
            </div>
          </div>
          {/* Hidden field so selection is submitted with the form */}
          <input type="hidden" name="usage" value={progressActive} />

          <div className=''>
            <div className="label">
              <IoKeyOutline className='text-gray-500' />
              <span className={`label-text ft-size14 text-gray-700 font-semibold`}>Ownership</span>
            </div>
            <InputToggle name='showMyCampaigns' text='Only show my campaigns' />
          </div>
          
          <div className="flex gap-2 ml-auto">
            <button type="button" className="btn shadow-sm shadow-gray-500/50 btn-purple">
              Apply filters
            </button>
            <button type="button" className="btn btn-ghost">
              Reset
            </button>
          </div>
        </div>
      </Form>
    </div>

    <div className='bg-base-100 rounded-box shadow-md p-4 mb-5'>
      <div className="overflow-x-auto overflow-y-auto max-h-96 w-auto max-w-full">
        <table className="table table-sm table-zebra table-auto min-w-full">
          {/* head */}
          <thead>
            <tr className='bg-lightest-purple ft-size12'>
              <th>ID</th>
              <th>Name</th>
              <th>Status</th>
              <th>Channel</th>
              <th>Audience count</th>
              <th>Owner</th>
              <th>Last modified</th>
              <th>Progress</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {
              campaignsData.map(rowData => {
                const {id, name, channel, audienceCount, owner, lastModified, status, progress} = rowData
                return (
                <tr key={id}>
                  <td>{id}</td>
                  <td className='font-semibold'><Link className='hover:underline'>{name}</Link></td>
                  <td><div className={`rounded-2xl inline-block px-2 py-1 text-xs ${getBadgeClass(status)}`}>{status}</div></td>
                  <td>{getChannelIcon(channel)}</td>
                  <td>{audienceCount}</td>
                  <td>{owner}</td>
                  <td>{lastModified}</td>
                  <td>
                    <div className="radial-progress bg-[#EFEBF7] text-[#8661c5]" style={{ "--value": `${progress}`, "--size": "3rem", "--thickness": "4px" }} aria-valuenow={progress} role="progressbar">
                      <span className='font-semibold text-[#7655AC]'>{progress}%</span>
                    </div>
                  </td>
                  <td>
                    <div className='flex gap-1'>
                      <button title='Configure audience' className="btn btn-icon btn-sm hover:bg-[#8661c5] rounded-pill group">
                        <BsPeopleFill className='text-[#8661c5] group-hover:text-white ft-size14' />
                      </button>
                      <button title='Edit' className="btn btn-icon btn-sm hover:bg-[#8661c5] rounded-pill group">
                        <MdEdit className='text-[#8661c5] group-hover:text-white ft-size14' />
                      </button>
                    </div>
                  </td>
                </tr>
                )
              })
            }
          </tbody>
        </table>
      </div>
    </div>
    </>
  )
}

export default Campaigns
