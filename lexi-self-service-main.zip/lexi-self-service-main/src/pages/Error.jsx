import React from 'react'
import { isRouteErrorResponse, useRouteError } from 'react-router-dom'

const Error = () => {
    const error = useRouteError()
    console.log(error);

    if(isRouteErrorResponse(error)) {
        if(error.status === 400) {
            return <div className="flex flex-col items-center justify-center min-h-screen text-center">
                        <h1 className="text-4xl font-bold mb-4">404 - Page not found</h1>
                        <p className="text-lg mb-4">Oops! This page doesn't exist.</p>
                    </div>
        }
    }

    return (
        <div className="flex flex-col items-center justify-center min-h-screen text-center">
            <h1 className="text-4xl font-bold mb-4">Oops! Something went wrong.</h1>
            <p className="text-lg mb-4">We're sorry, but an unexpected error has occurred.</p>
            <p className="italic"> {isRouteErrorResponse(error) ? error.statusText : error.message}</p>
        </div>
    )
}

export default Error
