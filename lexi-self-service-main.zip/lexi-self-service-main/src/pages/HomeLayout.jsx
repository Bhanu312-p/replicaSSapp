import React, { useState } from 'react'
import { Outlet, useNavigation } from 'react-router-dom'
import { Aside, Footer, Navbar, ScrollTop } from '../components';

const HomeLayout = () => {
  const [asideCollapsed, setAsideCollapsed] = useState(false)
  const toggleAside = () => setAsideCollapsed(!asideCollapsed)
  const navigation = useNavigation();
  const isLoading = navigation.state === 'loading'
  return (
    <>
    <ScrollTop />
    <div className='grid grid-rows-[auto_1fr_auto] min-h-dvh flex-r'>
      <Navbar toggleNav={toggleAside} navExtend={asideCollapsed} />
      {isLoading && (
        <div className='fixed inset-0 flex items-center justify-center bg-white opacity-80 z-50'>
          <span className='loading loading-ring loading-lg'></span>
        </div>
      )}
      <div className="h-16" />

      <Aside collapsed={asideCollapsed} />
      <main className={`${asideCollapsed ? 'ps-20' : 'ps-64'} bg-gray-100 min-w-0 transition-[padding] duration-300 ease-out`}>
        <div className='py-6 px-12'>
          <Outlet />
        </div>
        
      </main>
      <Footer footerExtend={asideCollapsed} />
      
    </div>
    </>
  )
}

export default HomeLayout
