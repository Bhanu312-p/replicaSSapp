import React from 'react'
import bannerBg from '../assets/banner-bg.jpg'
import { Link } from 'react-router-dom'
import { MdOutlineCampaign, MdOutlineRocketLaunch } from 'react-icons/md'
import { BsPeople } from 'react-icons/bs'

const Landing = () => {
  return (
    <>
      {/* <div>
        <h2 className='ft-size24 font-semibold mb-1'>Home</h2>
        <p>Start here to see Programs, Campaigns, Audiences, and Approvals.</p>
      </div> */}

      <div className="row mb-8">
        <div className="col">
          <div className='tile-gradient rounded-2xl border border-gray-100 px-6 py-8 custom-shadow md:col-span-2 bg-cover' style={{backgroundImage: `url(${bannerBg})`}}>
            <h1 className="ft-size28 text-white font-semibold mb-2">Learning Communications Portal</h1>
            <p className='text-white mb-5'>Programs flow from Azure DevOps intake; campaigns, audiences, and approvals live here.</p>
            <button className="btn bg-white rounded-2xl px-4 py-2 text-sm shadow flex items-center justify-center gap-2 transition hover:opacity-90 ">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-megaphone h-4 w-4" aria-hidden="true"><path d="M11 6a13 13 0 0 0 8.4-2.8A1 1 0 0 1 21 4v12a1 1 0 0 1-1.6.8A13 13 0 0 0 11 14H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z"></path><path d="M6 14a12 12 0 0 0 2.4 7.2 2 2 0 0 0 3.2-2.4A8 8 0 0 1 10 14"></path><path d="M8 6v8"></path></svg>
              <span>Start a Campaign</span>
            </button>
          </div>
        </div>
      </div>

      <div className='grid grid-cols-1 gap-4 md:grid-cols-3'>
        <Link to='/programs' className='relative overflow-hidden w-full rounded-2xl border border-gray-100 p-8 custom-shadow bg-white transition duration-300 ease-out hover:-translate-y-4'>
          <MdOutlineRocketLaunch className='abs-icon' />
          <h3 className='ft-size18 font-semibold mb-3'>View Programs</h3>
          <p>See Programs created from Azure DevOps when Comms support is needed.</p>
        </Link>
        <Link to='/campaigns' className='relative overflow-hidden w-full rounded-2xl border border-gray-100 p-8 custom-shadow bg-white transition duration-300 ease-out hover:-translate-y-4'>
          <MdOutlineCampaign className='abs-icon' />
          <h3 className='ft-size18 font-semibold mb-3'>Campaigns</h3>
          <p>Create and manage campaigns linked to Programs or standalone.</p>
        </Link>
        <Link to='/audiences' className='relative overflow-hidden w-full rounded-2xl border border-gray-100 p-8 custom-shadow bg-white transition duration-300 ease-out hover:-translate-y-4'>
          <BsPeople className='abs-icon' />
          <h3 className='ft-size18 font-semibold mb-3'>Audiences</h3>
          <p>Manage and segment learner audiences for targeting.</p>
        </Link>
      </div>
    </>
  )
}

export default Landing
