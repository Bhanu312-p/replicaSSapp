import React, { useState, useEffect, useRef } from 'react'
import { BsPeopleFill } from 'react-icons/bs'
import { CiViewList } from 'react-icons/ci'
import { MdCampaign, MdDelete, MdDeleteForever, MdOutlineTextSnippet, MdTouchApp } from 'react-icons/md'
import { RiDraftLine, RiUpload2Fill } from 'react-icons/ri'
import { Form, useParams, useLoaderData } from 'react-router-dom'
import { InputSearch, InputSelect, InputText, InputTextarea } from '../components'
import { FaPeopleGroup, FaRegCalendarCheck } from 'react-icons/fa6'
import { IoKeyOutline, IoPeopleOutline } from 'react-icons/io5'
import { FaRegCalendarTimes } from 'react-icons/fa'
import { LuRefreshCcw } from 'react-icons/lu'

const audienceListData = [
  {
    id: "aud-sales",
    name: "Skills Challenge – Sales Audience",
    description: "Sellers in eligible countries (excludes works council).",
    size: 12000,
  },
  {
    id: "aud-tech",
    name: "Skills Challenge – Technical Audience",
    description: "Technical roles (CSA, SA, etc.) in eligible countries.",
    size: 8000,
  },
  {
    id: "aud-all-mcaps",
    name: "All MCAPS – Global",
    description: "All MCAPS sellers and technical roles worldwide.",
    size: 65000,
  },
]

const approvedTemplatesData = [
    {
    id: "tmpl-skill-seller-announce",
    name: "Skills Challenge – Seller Announcement",
    channel: "Email",
    description: "Initial announcement email for sellers.",
    status: "Approved",
  },
  {
    id: "tmpl-skill-tech-announce",
    name: "Skills Challenge – Technical Announcement",
    channel: "Email",
    description: "Initial announcement email for technical audience.",
    status: "Approved",
  },
  {
    id: "tmpl-skill-reminder",
    name: "Skills Challenge – Reminder",
    channel: "Email",
    description: "General reminder email template.",
    status: "Approved",
  }
]

export const loader = async({ params }) => {
    const { id } = params;
    
    // TODO: Fetch campaign details from Dataverse endpoint
    // const response = await fetch(`/api/dataverse/campaigns/${id}`);
    // const campaignData = await response.json();
    // return campaignData;
    
    // For now, return the campaign ID so it can be displayed

    const loaderData = {
      id: id,
      name: '',
      purpose: '',
      goLiveDate: '',
      endDate: '',
      audienceList: [],
      campaignTouchpoints: []
    };
    return { id, loaderData };
}

export const action = async ({ request, params }) => {
  const form = await request.formData();
  const raw = {};
  for (const [k, v] of form.entries()) {
    if (Object.prototype.hasOwnProperty.call(raw, k)) {
      if (!Array.isArray(raw[k])) raw[k] = [raw[k]];
      raw[k].push(v);
    } else {
      raw[k] = v;
    }
  }

  // Build touchpoints array from keys like touchpoint_1, channel_1, subject_1, ...
  const touchpointMap = {};
  for (const key of Object.keys(raw)) {
    const m = key.match(/(.+)_([0-9]+)$/);
    if (m) {
      const field = m[1];       // e.g. 'touchpoint', 'channel', 'subject'
      const tpId = Number(m[2]); // e.g. 1, 2, ...
      touchpointMap[tpId] ??= {};
      touchpointMap[tpId][field] = raw[key];
    }
  }
  const campaignTouchpoints = Object.keys(touchpointMap)
    .sort((a,b)=>Number(a)-Number(b))
    .map(i => touchpointMap[i]);

  // Structure the submission data like loaderData
  const campaign = {
    id: params.id || null,
    campaignName: raw.campaignName || '',
    campaignOwner: raw.campaignOwner || '',
    targetDate: raw.targetDate || '',
    endDate: raw.endDate || '',
    campaignDescription: raw.campaignDescription || '',
    audienceList: [],
    campaignTouchpoints: campaignTouchpoints
  };

  // Now you can send `campaign` to your Dataverse endpoint or DB
  console.log('Action has campaign object:', campaign);

  // return something or redirect
  return null;
};

const NewCampaign = () => {
    const { id, loaderData } = useLoaderData();
    const { name, purpose, goLiveDate, endDate, audienceList, campaignTouchpoints } = loaderData || {}
    const [formStep, setFormStep] = useState(1)
    const [isAudienceModalOpen, setIsAudienceModalOpen] = useState(false)
    const [checkedIds, setCheckedIds] = useState([])
    const [attachedAudiences, setAttachedAudiences] = useState([])

    // Touchpoints state: array of { id, template }
    const [touchpoints, setTouchpoints] = useState([
        { id: 1, template: null }
    ])
    const [tpCounter, setTpCounter] = useState(2)

    // Template modal state
    const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false)
    const [templateModalTargetId, setTemplateModalTargetId] = useState(null)
    const [templateSearch, setTemplateSearch] = useState('')
    const formId = 'campaignForm'
    const formRef = useRef(null)

    const [summary, setSummary] = useState({ campaignName: '', campaignOwner: '', targetDate: '' })
    const [summaryTouchpoints, setSummaryTouchpoints] = useState(0)

    // initialize attached audiences and touchpoints from loaderData when editing
    useEffect(() => {
        if (Array.isArray(audienceList) && audienceList.length > 0) {
            setAttachedAudiences(audienceList)
        }
        if (Array.isArray(campaignTouchpoints) && campaignTouchpoints.length > 0) {
            const mapped = campaignTouchpoints.map((t, i) => ({
                id: i + 1,
                template: t.template || null,
                name: t.name || t.touchpointName || '',
                channel: t.channel || '',
                audience: t.audience || '',
                scheduled: t.scheduled || t.goLiveDate || '',
                subject: t.subject || '',
                preheader: t.preheader || '',
                emailBody: t.emailBody || '',
                ctaLabel: t.ctaLabel || '',
                ctaLink: t.ctaLink || ''
            }))
            setTouchpoints(mapped)
            setTpCounter(mapped.length + 1)
        }
    }, [audienceList, campaignTouchpoints])

    const collectFormValues = (formEl) => {
        const fd = new FormData(formEl)
        const out = {}
        for (const [k, v] of fd.entries()) {
            if (Object.prototype.hasOwnProperty.call(out, k)) {
                if (!Array.isArray(out[k])) out[k] = [out[k]]
                out[k].push(v)
            } else {
                out[k] = v
            }
        }
        return out
    }

    const handlePreview = () => {
        const formEl = document.getElementById(formId)
        if (!formEl) return console.warn('Form not found')
        const values = collectFormValues(formEl)
        
        // Build touchpointMap from form values
        const touchpointMap = {}
        for (const key of Object.keys(values)) {
            const m = key.match(/(.+)_([0-9]+)$/)
            if (m) {
                const field = m[1]
                const tpId = Number(m[2])
                touchpointMap[tpId] ??= {}
                touchpointMap[tpId][field] = values[key]
            }
        }
        const campaignTouchpoints = Object.keys(touchpointMap)
            .sort((a, b) => Number(a) - Number(b))
            .map(i => touchpointMap[i])

        // Structure the preview data like loaderData
        const previewData = {
            id: id,
            campaignName: values.campaignName || '',
            campaignOwner: values.campaignOwner || '',
            targetDate: values.targetDate || '',
            endDate: values.endDate || '',
            campaignDescription: values.campaignDescription || '',
            audienceList: attachedAudiences,
            campaignTouchpoints: campaignTouchpoints
        }
        
        console.log('Form preview values:', previewData)
    }

    const handleSubmit = (e) => {
        const values = collectFormValues(e.target)
        
        // Build touchpointMap from form values
        const touchpointMap = {}
        for (const key of Object.keys(values)) {
            const m = key.match(/(.+)_([0-9]+)$/)
            if (m) {
                const field = m[1]
                const tpId = Number(m[2])
                touchpointMap[tpId] ??= {}
                touchpointMap[tpId][field] = values[key]
            }
        }
        const campaignTouchpoints = Object.keys(touchpointMap)
            .sort((a, b) => Number(a) - Number(b))
            .map(i => touchpointMap[i])

        // Structure the submission data like loaderData
        const submissionData = {
            id: id,
            campaignName: values.campaignName || '',
            campaignOwner: values.campaignOwner || '',
            targetDate: values.targetDate || '',
            endDate: values.endDate || '',
            campaignDescription: values.campaignDescription || '',
            audienceList: attachedAudiences,
            campaignTouchpoints: campaignTouchpoints
        }
        
        console.log('Submitting form values:', submissionData)
        // allow normal React Router Form submission to continue
    }

    const audienceCountForSidebar = attachedAudiences.length
    const audienceLabel = audienceCountForSidebar === 1 ? '1 audience' : `${audienceCountForSidebar} audiences`
    const touchpointLabel = summaryTouchpoints === 1 ? '1 touchpoint' : `${summaryTouchpoints} touchpoints`

    const handleNext = () => {
        if (formStep === 1) {
            const el = formRef.current
            const elms = el?.elements
            setSummary({
                campaignName: elms?.['campaignName']?.value || '',
                campaignOwner: elms?.['campaignOwner']?.value || '',
                targetDate: elms?.['targetDate']?.value || ''
            })
        }
        if (formStep === 3) {
            setSummaryTouchpoints(touchpoints.length)
        }
        if (formStep < 4) setFormStep(s => s + 1)
    }

  return (
    <>
    <div className='mb-7'>
      <h2 className='ft-size20 font-semibold mb-1'>Campaign - {id}</h2>
      <p>Step through the wizard to define campaign metadata, audiences, and touchpoints.</p>
    </div>

    <div className='w-[96%] grid grid-cols-4 mb-7'>
        <div className="flex flex-col">
            <button className={`z-10 ${ formStep > 1 ? 'bg-success ring-green-300' : 'bg-[#c03BC4] ring-pink-300' } rounded-full w-8 h-8 flex items-center justify-center text-white font-bold ring-4 `}>
                <CiViewList className='ft-size18' />
            </button>
            <span className="mt-2 text-xs font-semibold -ml-3">Overview</span>
            <div className='flex z-0'>
                <progress className="progress progress-success w-full -mt-10" value={formStep > 1 ? 100 : 0} max="100"></progress>
            </div>
        </div>
        <div className="flex flex-col">
            <div className='-ml-3 z-10'>
                <button className={`${formStep === 1 ? 'bg-gray-100 ring-gray-300 text-gray-700' : formStep === 2 ? 'bg-[#c03BC4] ring-pink-300 text-white' : formStep > 2 ? 'bg-success ring-green-300 text-white' : ''} rounded-full w-8 h-8 flex items-center justify-center font-bold ring-4`}>
                    <BsPeopleFill className='ft-size18' />
                </button>
                <span className="mt-2 text-xs font-semibold -ml-3">Audiences</span>
            </div>
            <div className='flex z-0'>
                <progress className="progress progress-success w-full -mt-10" value={formStep > 2 ? 100 : 0} max="100"></progress>
            </div>
        </div>
        <div className="flex flex-col">
            <div className='-ml-3 z-10'>
                <button className={`${formStep === 4 ? 'bg-success ring-green-300 text-white' : formStep === 3 ? 'bg-[#c03BC4] ring-pink-300 text-white' : formStep < 3 ? 'bg-gray-100 ring-gray-300 text-gray-700' : ''} rounded-full w-8 h-8 flex items-center justify-center font-bold ring-4`}>
                    <MdTouchApp className='ft-size18' />
                </button>
                <span className="mt-2 text-xs font-semibold -ml-4">Touchpoints</span>
            </div>
            <div className='flex z-0'>
                <progress className="progress progress-success w-full -mt-10" value={formStep === 4 ? 100 : 0} max="100"></progress>
            </div>
        </div>
        <div className="flex flex-col">
            <div className='-ml-3 z-10'>
                <button className={`${ formStep === 4 ? 'bg-[#c03BC4] ring-pink-300' : 'bg-gray-100 ring-gray-300' } rounded-full w-8 h-8 flex items-center justify-center text-white font-bold ring-4`}>
                    <RiUpload2Fill className={`ft-size18 ${formStep !== 4 && 'text-gray-700'}`} />
                </button>
                <span className="mt-2 text-xs font-semibold -ml-8">Review & submit</span>
            </div>
        </div>
    </div>

    <div className='grid md:grid-cols-8 gap-4'>
        <div className='col-span-6'>
            <Form method='get' id={formId} ref={formRef} onSubmit={handleSubmit}>
            <div style={{ display: formStep === 1 ? 'block' : 'none' }}>
              <div className='bg-base-100 rounded-box shadow-md mb-5'>
                <div className='border-b border-gray-200 p-4 '>
                    <h3 className='ft-size16 font-semibold'>Campaign Overview</h3>
                </div>
                <div className='p-4'>
                        <div className="grid md:grid-cols-2 gap-4 justify-between items-end mb-3">
                            <InputText type='text' text='Campaign name' name='campaignName' required={true} size='input-sm' placeholder='ex. FY25 Q2 Skills Challenge - EMEA' defaultValue={name || ''} />
                            <InputText type='text' text='Campaign owner' name='campaignOwner' size='input-sm' placeholder='ex. Jane Doe (Program owner)' defaultValue={loaderData?.owner || purpose || ''} />
                        </div>
                        <div className="grid md:grid-cols-2 gap-4 justify-between items-end mb-3">
                            <InputText type='date' text='Target go-live date' name='targetDate' size='input-sm' defaultValue={goLiveDate || ''} />
                            <InputText type='date' text='End date (derived)' name='endDate' size='input-sm' defaultValue={endDate || ''} />
                        </div>
                        <InputTextarea text='Campaign description/context' name='campaignDescription' size='input-sm' defaultValue={loaderData?.description || ''} />
                </div>
              </div>
            </div>
            
            <div style={{ display: formStep === 2 ? 'block' : 'none' }}>
              <div className='bg-base-100 rounded-box shadow-md mb-5'>
                <div className='flex justify-between items-center border-b border-gray-200 p-4'>
                    <div className="">
                        <h3 className='ft-size16 font-semibold mb-0'>Audiences</h3>
                        <p className='text-sm ft-size12 text-gray-500 w-96'>Attach one or more audiences. These will be available to assign per touchpoint in Step 3.</p>
                    </div>
                    <div className='flex gap-1'>
                        <div className="tooltip">
                            <div className="tooltip-content">
                                <div className="text-sm ft-size12">
                                    Go to the Audience segmentation report to create new audiences.
                                </div>
                            </div>
                            <a href='#' target='_blank' className='btn btn-sm'>Create audiences</a>
                        </div>
                        <button onClick={() => {
                            // pre-check already attached audiences in the modal
                            setCheckedIds(attachedAudiences.map(a => a.id))
                            setIsAudienceModalOpen(true)
                        }} className='md:text-end btn btn-sm shadow-sm shadow-gray-500/50 btn-purple'>Manage Audiences</button>
                    </div>
                </div>
                <div className='p-4'>
                    <p>Attached audiences</p>
                    <div className='mt-3'>
                        {attachedAudiences.length === 0 && <p className='text-sm text-gray-500'>No audiences attached</p>}
                        <div className='flex flex-wrap gap-2'>
                            {attachedAudiences.map(a => (
                                <div key={a.id} className='flex items-start gap-2 px-3 py-1 rounded bg-gray-100 border border-gray-200'>
                                    <div>
                                        <div className='text-sm font-semibold'>{a.name}</div>
                                        <div className='text-sm text-[12px]'>{a.description}</div>
                                        <div className='flex gap-2 items-center text-gray-500'>
                                            <FaPeopleGroup />
                                            <p className='mb-0'>{a.size.toLocaleString()}</p>
                                        </div>
                                    </div>
                                    <button onClick={() => {
                                        setAttachedAudiences(prev => prev.filter(x => x.id !== a.id))
                                    }} className='text-gray-500 hover:text-gray-700 ml-2 cursor-pointer' aria-label={`Remove ${a.name}`}>
                                        ×
                                    </button>
                                </div>
                                
                            ))}
                        </div>
                    </div>
                </div>
            </div>
            </div>

            {/* Audience modal */}
            {isAudienceModalOpen && (
                <div className='fixed inset-0 z-50 flex items-center justify-center'>
                    <div className='absolute inset-0 bg-black/40' onClick={() => setIsAudienceModalOpen(false)}></div>
                    <div className='relative w-[90%] max-w-2xl bg-white rounded-lg shadow-lg overflow-hidden'>
                        <div className='flex items-center justify-between px-5 py-4 border-b border-gray-200'>
                            <div>
                                <h3 className='ft-size16 text-md font-semibold'>Manage audiences</h3>
                                <p className='ft-size12 text-xs text-gray-600'>Select one or more audience lists to attach to this campaign.</p>
                            </div>
                            <button className='btn btn-sm hover:text-gray-700'>
                                <LuRefreshCcw /> Refresh audience
                            </button>
                        </div>
                        <div className='px-5 py-4 max-h-[60vh] overflow-y-auto'>
                            
                            <div className='space-y-3'>
                                {audienceListData.map(aud => {
                                    const checked = checkedIds.includes(aud.id)
                                    return (
                                        <label key={aud.id} className='flex items-start gap-3 p-3 rounded hover:bg-gray-50 border border-gray-100 hover:border-purple-300 cursor-pointer'>
                                            <input type='checkbox' checked={checked} onChange={(e) => {
                                                if (e.target.checked) {
                                                    setCheckedIds(prev => [...prev, aud.id])
                                                } else {
                                                    setCheckedIds(prev => prev.filter(id => id !== aud.id))
                                                }
                                            }} className='checkbox checkbox-sm checkbox-secondary checked:bg-[#8661c5] checked:border-[#8661c5] mt-1' />
                                            <div>
                                                <div className='font-medium'>{aud.name}</div>
                                                <div className='text-sm ft-size12'>{aud.description}</div>
                                                <div className='flex gap-2 items-center text-gray-500'>
                                                    <FaPeopleGroup />
                                                    <p className='mb-0'>{aud.size.toLocaleString()}</p>
                                                </div>
                                            </div>
                                        </label>
                                    )
                                })}
                            </div>
                        </div>
                        <div className='flex items-center justify-end gap-3 px-5 py-4 border-t border-gray-200'>
                            <button onClick={() => setIsAudienceModalOpen(false)} className='btn btn-sm btn-ghost'>Cancel</button>
                            <button onClick={() => {
                                // replace attachedAudiences with the currently selected lists
                                const selected = audienceListData.filter(a => checkedIds.includes(a.id))
                                setAttachedAudiences(selected)
                                setIsAudienceModalOpen(false)
                            }} className='btn btn-sm shadow-sm shadow-gray-500/50 btn-purple'>Save audience</button>
                        </div>
                    </div>
                </div>
            )}
            
            <div style={{ display: formStep === 3 ? 'block' : 'none' }}>
              <div className='bg-base-100 rounded-box shadow-md mb-5'>
                <div className='border-b border-gray-200 p-4 flex justify-between items-center'>
                    <div>
                        <h3 className='ft-size16 font-semibold'>Touchpoints</h3>
                        <p className='text-sm ft-size12 text-gray-500 w-lg'>Define the emails / Teams messages for this campaign. Each touchpoint is assigned to one audience and must use an approved template before personalization.</p>
                    </div>
                    <div className=''>
                        <button type='button' className='text-end btn btn-sm shadow-sm shadow-gray-500/50 btn-purple' onClick={() => {
                            setTouchpoints(prev => [...prev, { id: tpCounter, template: null }])
                            setTpCounter(prev => prev + 1)
                        }}>Add touchpoint</button>
                    </div>
                </div>
                <div className='p-4'>
                    {touchpoints.length === 0 ? (
                        <p className='text-sm text-gray-500'>No touchpoints have been added yet.</p>
                    ) : (
                        <div>
                            {touchpoints.map((tp, idx) => (
                            <div key={tp.id} className='touchpoint-div p-3 rounded bg-gray-100 border border-gray-200 mb-5'>
                                <div className='flex justify-between items-center mb-3'>
                                    <button type='button' className='btn btn-sm' onClick={() => {
                                        setTemplateModalTargetId(tp.id)
                                        setTemplateSearch('')
                                        setIsTemplateModalOpen(true)
                                    }}>{tp.template ? `Change template` : 'Select template'}</button>
                                    <div className='text-right'>
                                        <button title='Remove touchpoint' className="btn btn-icon btn-sm rounded-pill group" onClick={() => {
                                            setTouchpoints(prev => prev.filter(t => t.id !== tp.id))
                                        }}>
                                            <MdDelete className='text-[#666] ft-size14' />
                                        </button>
                                    </div>
                                </div>
                                <div className='grid md:grid-cols-4 gap-3 justify-between items-end mb-5'>
                                    <InputText type='text' text='Touchpoint' name={`touchpoint_${tp.id}`} size='input-sm' placeholder='Touchpoint name' defaultValue={tp.name || tp.touchpointName || ''} />
                                    <InputSelect text='Channel' name={`channel_${tp.id}`} list={['Email']} size='select-sm' defaultValue={tp.channel || ''} />
                                    <InputSelect text='Audience' name={`audience_${tp.id}`} list={['Skills challenge sales audience', 'Skills challenge technical audience']} size='select-sm' defaultValue={tp.audience || ''} />
                                    <InputText type='datetime-local' text='Scheduled send' name={`scheduled_${tp.id}`} size='input-sm' defaultValue={tp.scheduled || ''} />
                                </div>
                                <div className='mb-3'>
                                    <h4 className='ft-size12'><span className='font-semibold'>Template</span> — {tp.template?.name || 'No template selected'}</h4>
                                </div>

                                {tp.template && (
                                    <div className='email-fields p-3 rounded bg-white border border-gray-200'>
                                        <div className='grid md:grid-cols-2 gap-3 justify-between items-end mb-3'>
                                            <InputText type='text' text='Subject override' name={`subject_${tp.id}`} size='input-sm' placeholder='Leave blank to use template subject' defaultValue={tp.subject || ''} />
                                            <InputText type='text' text='Preheader' name={`preheader_${tp.id}`} size='input-sm' placeholder='Optional short teaser line' defaultValue={tp.preheader || ''} />
                                        </div>
                                        <div className='mb-3'>
                                            <InputTextarea text='Intro/body snippet' name={`emailBody_${tp.id}`} size='input-sm' placeholder='Optional intro paragraph to inject into template body' defaultValue={tp.emailBody || ''} />
                                        </div>
                                        <div className='grid md:grid-cols-2 gap-3 justify-between items-end'>
                                            <InputText type='text' text='CTA label' name={`ctaLabel_${tp.id}`} size='input-sm' placeholder='CTA label' defaultValue={tp.ctaLabel || ''} />
                                            <InputText type='text' text='CTA URL' name={`ctaLink_${tp.id}`} size='input-sm' placeholder='CTA URL' defaultValue={tp.ctaLink || ''} />
                                        </div>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                    )}
                    {/* Template selection modal */}
                    {isTemplateModalOpen && (
                        <div className='fixed inset-0 z-50 flex items-center justify-center'>
                            <div className='absolute inset-0 bg-black/40' onClick={() => setIsTemplateModalOpen(false)}></div>
                            <div className='relative w-[90%] max-w-2xl bg-white rounded-lg shadow-lg overflow-hidden'>
                                <div className='flex items-center justify-between px-5 py-4 border-b border-gray-200'>
                                    <div>
                                        <h3 className='ft-size16 text-md font-semibold'>Select template</h3>
                                        <p className='ft-size12 text-xs text-gray-600'>Choose an approved template for this touchpoint.</p>
                                    </div>
                                    <div className='w-1/3'>
                                        <input value={templateSearch} onChange={(e) => setTemplateSearch(e.target.value)} className='input input-sm w-full' placeholder='Search templates...' />
                                    </div>
                                </div>
                                <div className='px-5 py-4 max-h-[60vh] overflow-y-auto space-y-3'>
                                    {approvedTemplatesData.filter(t => t.name.toLowerCase().includes(templateSearch.toLowerCase())).map(tmpl => (
                                        <div key={tmpl.id} className='flex items-center justify-between p-3 rounded hover:bg-gray-50 border border-gray-100'>
                                            <div>
                                                <div className='font-medium'>{tmpl.name}</div>
                                                <div className='text-sm ft-size12 text-gray-600'>{tmpl.description}</div>
                                                <div className='text-sm ft-size12 text-gray-500'>Channel: {tmpl.channel}</div>
                                            </div>
                                            <div className='flex gap-2 items-center'>
                                                <button className='btn btn-sm btn-ghost' onClick={() => setIsTemplateModalOpen(false)}>Cancel</button>
                                                <button className='btn btn-sm btn-purple' onClick={() => {
                                                    setTouchpoints(prev => prev.map(tp => tp.id === templateModalTargetId ? { ...tp, template: tmpl } : tp))
                                                    setIsTemplateModalOpen(false)
                                                }}>Use template</button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            </div>

            <div style={{ display: formStep === 4 ? 'block' : 'none' }}>
              <div className='bg-base-100 rounded-box shadow-md mb-5'>
                <div className='border-b border-gray-200 p-4 '>
                    <h3 className='ft-size16 font-semibold'>Review & Submit</h3>
                </div>
                <div className='p-4'>
                    <div className='grid md:grid-cols-1 gap-4 mb-4'>
                        <div className='flex items-center gap-1'>
                            <MdCampaign className='text-gray-500' />
                            <div className='text-sm'>
                                <span className='font-semibold'>Campaign name: </span>
                                <span>{document.getElementById(formId)?.elements['campaignName']?.value || ''}</span>
                            </div>
                        </div>
                        <div className='flex items-center gap-1'>
                            <IoKeyOutline className='text-gray-500' />
                            <div className='text-sm'>
                                <span className='font-semibold'>Campaign owner: </span>
                                <span>{document.getElementById(formId)?.elements['campaignOwner']?.value || ''}</span>
                            </div>
                        </div>
                    </div>
                    <div className='grid md:grid-cols-1 gap-4 mb-4'>
                        <div className='flex items-center gap-1'>
                            <RiDraftLine className='text-gray-500' />
                            <div className='text-sm'>
                                <span className='font-semibold'>Draft created: </span>
                                <span>2025-12-01</span>
                            </div>
                        </div>
                    </div>
                    <div className='grid md:grid-cols-1 gap-4 mb-4'>
                        <div className='flex items-center gap-1'>
                            <FaRegCalendarCheck className='text-gray-500' />
                            <div className='text-sm'>
                                <span className='font-semibold'>Target go-live date: </span>
                                <span>{document.getElementById(formId)?.elements['targetDate']?.value || ''}</span>
                            </div>
                        </div>
                    </div>
                    <div className='mb-4'>
                        <div className='flex items-center gap-1'>
                            <MdOutlineTextSnippet className='text-gray-500' />
                            <div className='font-semibold text-sm'>Description: </div>
                        </div>
                        <p>
                            {document.getElementById(formId)?.elements['campaignDescription']?.value || ''}
                        </p>
                    </div>
                    <div className=''>
                        <div className='flex items-center gap-1 mb-1'>
                            <IoPeopleOutline className='text-gray-500' />
                            <div className='font-semibold text-sm'>Audiences: </div>
                        </div>
                        <div className='flex flex-wrap gap-2'>
                            {attachedAudiences.map(a => (
                                <div key={a.id} className='flex items-center gap-2 px-3 py-1 rounded bg-gray-100 border border-gray-200'>
                                    <div>
                                        <div className='text-sm font-semibold'>{a.name}</div>
                                        <div className='text-sm text-[12px]'>{a.description}</div>
                                        <div className='flex gap-2 items-center text-gray-500'>
                                            <FaPeopleGroup />
                                            <p className='mb-0'>{a.size.toLocaleString()}</p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
            </div>

            <div className='flex justify-between mb-7'>
                <div className='flex gap-2'>
                    <button className='btn' type='button' disabled={formStep === 1} onClick={() => setFormStep(s => Math.max(1, s - 1))}>Previous</button>
                    {/* <button className='btn btn-ghost' type='button' onClick={handlePreview}>Preview</button> */}
                </div>
                <button
                    className='btn shadow-sm shadow-gray-500/50 btn-purple'
                    type={formStep === 4 ? 'submit' : 'button'}
                    onClick={() => { if (formStep < 4) handleNext() }}
                >
                    {formStep === 4 ? 'Submit' : 'Next'}
                </button>
            </div>
            </Form>
            
        </div>
        
        <div className='col-span-2'>
            <div className='bg-base-100 rounded-box shadow-md mb-5'>
                <div className='border-b border-gray-200 p-3'>
                    <h3 className='ft-size14 font-semibold'>Campaign status</h3>
                    <p className='text-sm ft-size12 text-gray-500'>
                        Quick view of key details.
                    </p>
                </div>
                <div className='p-3 space-y-2 text-xs text-gray-700 form-display'>
                    <div className='rounded-2xl inline-block px-2 py-1 text-xs bg-green-100 text-green-700'>
                        In progress
                    </div>
                    <div>
                        <span className="font-semibold">Name: </span><span>{summary.campaignName || ''}</span>
                    </div>
                    <div>
                        <span className="font-semibold">Owner: </span><span>{summary.campaignOwner || ''}</span>
                    </div>
                    <div>
                        <span className="font-semibold">Draft created: </span><span>2025-12-01</span>
                    </div>
                    <div>
                        <span className="font-semibold">Target go-live: </span><span>{summary.targetDate || ''}</span>
                    </div>
                    <div>
                        <span className="font-semibold">Audiences attached: </span><span>{audienceLabel}</span>
                    </div>
                    <div>
                        <span className="font-semibold">Touchpoints: </span><span>{touchpointLabel}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    
    </>
  )
}

export default NewCampaign
