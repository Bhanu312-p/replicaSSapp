import React, { useState } from 'react'
import { BiSortAlt2 } from 'react-icons/bi';
import { FaExternalLinkAlt } from 'react-icons/fa';
import { GrStatusGood } from 'react-icons/gr';
import { MdContentPasteSearch, MdOutlineRocketLaunch } from 'react-icons/md';
import { Form, Link } from 'react-router-dom'
import { InputSearch, InputSelect, InputText } from '../components';
import { VscAzureDevops } from 'react-icons/vsc';
import { IoIosLink } from 'react-icons/io';
import { BsCalendar2Date } from 'react-icons/bs';
import { FaRegUser } from 'react-icons/fa6';

const programsData = [
  {
    id: "p-001",
    name: "FY25 Readiness Refresh",
    adoId: "102938",
    adoUrl:
      "https://dev.azure.com/contoso/MCAPS/_workitems/edit/102938",
    goLive: '01-01-2025',
    owner: "J. Rivera",
    status: "upcoming",
    campaigns: 2,
    commsNeeded: true,
  },
  {
    id: "p-002",
    name: "Azure Fundamentals Sprint",
    adoId: "104477",
    adoUrl:
      "https://dev.azure.com/contoso/MCAPS/_workitems/edit/104477",
    goLive: '01-01-2025',
    owner: "S. Lee",
    status: "active",
    campaigns: 4,
    commsNeeded: true,
  },
  {
    id: "p-003",
    name: "Field Enablement – Q1",
    adoId: "100112",
    adoUrl: "",
    goLive: '01-01-2025',
    owner: "Unassigned",
    status: "blocked",
    campaigns: 0,
    commsNeeded: false,
  },
  {
    id: "p-004",
    name: "Partner Skilling Pilot",
    adoId: "100201",
    adoUrl:
      "https://dev.azure.com/contoso/MCAPS/_workitems/edit/100201",
    goLive: '01-01-2025',
    owner: "A. Chen",
    status: "completed",
    campaigns: 6,
    commsNeeded: true,
  },
]

const statusOptions = ['Upcoming', 'Active', 'Completed', 'Blocked']
const sortOptions = ['Name ↑', 'Name ↓', 'Go-Live ↑', 'Go-Live ↓']

  
const getBadgeClass = (status) => {
  switch (status) {
    case 'upcoming':
      return 'bg-blue-100 text-blue-700';
    case 'active':
      return 'bg-green-100 text-green-700';
    case 'blocked':
      return 'bg-red-100 text-red-700';
    case 'completed':
      return 'bg-teal-100 text-teal-700';
    default:
      return 'bg-green-100 text-green-700';
  }
};

export const action = async(request) => {
  console.log(request);
  
  return null
}


const Programs = () => {
  const [openDrawer, setOpenDrawer] = useState(false)

  return (
    <>
    <div className='md:flex justify-between items-center pb-2 text-xs mb-5'>
      <div className="">
        <h2 className='ft-size24 font-semibold mb-1'>Programs</h2>
        <p>Programs are created from Azure DevOps intake when 'Communications support needed' is toggled.</p>
      </div>
      <button onClick={() => setOpenDrawer(true)} className='md:text-end btn shadow-sm shadow-gray-500/50 btn-magenta'>+ New program</button>
    </div>

    <div className='bg-base-100 rounded-box shadow-md mb-5'>
      <Form method='get' className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-8 gap-3 justify-between items-end">
          <div className='col-span-3'>
            <InputSearch text='Search' name='search' placeholder='Search...' Icon={MdContentPasteSearch} />
          </div>
          <div className="grid grid-cols-1 col-span-3 md:grid-cols-2 gap-3">
            <InputSelect text='Status' name='status' list={['All statuses', ...statusOptions]} Icon={GrStatusGood} />
            <InputSelect text='Sort by' name='sort' list={sortOptions} Icon={BiSortAlt2} />
          </div>
          <div className="flex gap-2">
            <button type="button" className="btn shadow-sm shadow-gray-500/50 btn-purple">
              Apply filters
            </button>
            <button type="button" className="btn btn-ghost">
              Reset
            </button>
          </div>
        </div>

        
      </Form>
    </div>

    <div className='bg-base-100 rounded-box shadow-md p-4 mb-5'>
      <div className="overflow-x-auto">
        <table className="table table-zebra">
          {/* head */}
          <thead>
            <tr className='bg-lightest-purple'>
              <th>Program</th>
              <th>Go-Live</th>
              <th>Owner</th>
              <th>Status</th>
              <th>Campaigns</th>
              <th>ADO</th>
            </tr>
          </thead>
          <tbody>
            {
              programsData.map(rowData => {
                const {id, name, adoId, adoUrl, goLive, status, owner, campaigns, commsNeeded} = rowData
                return (
                <tr key={id}>
                  <td className='font-semibold'><Link className='hover:underline'>{name}</Link></td>
                  <td>{goLive}</td>
                  <td>{owner}</td>
                  <td><div className={`rounded-2xl inline-block px-2 py-1 text-xs ${getBadgeClass(status)}`}>{status}</div></td>
                  <td>{campaigns}</td>
                  <td><a href={adoUrl} target='_blank' className='hover:underline inline-flex gap-1 items-center'><span>{adoId}</span> <span><FaExternalLinkAlt /></span></a></td>
                </tr>
                )
              })
            }
          </tbody>
        </table>
      </div>
    </div>

    <div className="drawer drawer-end">
      <input id="my-drawer-1" checked={openDrawer} onChange={(e) => setOpenDrawer(e.target.checked)} type="checkbox" className="drawer-toggle" />
      <div className="drawer-side z-40">
        <label htmlFor="my-drawer-1" aria-label="close sidebar" className="drawer-overlay"></label>
        <Form method='post' className="menu bg-base-100 min-h-full w-80 p-4">
          <div className="flex items-center justify-between pb-3 mb-5 border-b border-gray-200">
            <h3 className="text-base font-semibold">New Program</h3>
            <button type='button' onClick={() => setOpenDrawer(false)} className="rounded-2xl cursor-pointer border border-gray-200 px-3 py-1 text-xs hover:bg-gray-50">x</button>
          </div>
          <div className='mb-4'>
            <InputText type='text' text='Program Name' required={true} name='program' size='input-sm' Icon={MdOutlineRocketLaunch} placeholder='Enter program name' />
          </div>
          <div className='mb-4'>
            <InputText type='text' text='ADO Work Item URL' name='adoURL' size='input-sm' Icon={IoIosLink} placeholder='https://dev.azure.com/.../_workitems/edit/123456' />
          </div>
          <div className='mb-4'>
            <InputText type='text' text='ADO ID (optional)' name='adoID' size='input-sm' Icon={VscAzureDevops} placeholder='123456' />
          </div>
          <div className='mb-4'>
            <InputText type='date' text='Go-Live Date' required={true} name='GoLiveDate' size='input-sm' Icon={BsCalendar2Date} />
          </div>
          <div className='mb-4'>
            <InputText type='text' text='Owner' name='owner' size='input-sm' Icon={FaRegUser} placeholder='Full name' />
          </div>
          <div>
            <InputSelect text='Status' name='status' list={statusOptions} size='select-sm' Icon={GrStatusGood} />
          </div>
          
          <div className="mt-5 flex gap-2">
            <button type="submit" className="btn btn-sm shadow-sm shadow-gray-500/50 btn-purple">Create Program</button>
            <button type="button" onClick={() => setOpenDrawer(false)} className="btn btn-sm btn-ghost">Cancel</button>
          </div>
        </Form>
      </div>
    </div>

    </>
  )
}

export default Programs
