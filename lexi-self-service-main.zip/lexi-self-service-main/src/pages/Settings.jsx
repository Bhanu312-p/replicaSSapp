import React from 'react'
import { CgProfile } from 'react-icons/cg'
import { FaArrowRight } from 'react-icons/fa6'
import { GoVideo } from 'react-icons/go'
import { GrDocumentText } from 'react-icons/gr'
import { Link } from 'react-router-dom'

const Settings = () => {
  return (
    <>
    <div className='mb-5'>
      <h2 className='ft-size24 font-semibold mb-1'>Settings</h2>
      <p>User preferences, training, and support.</p>
    </div>
    <div className='grid gap-8 md:grid-cols-3'>
      <div className='col-span-2'>
        <ul className="list bg-base-100 rounded-box shadow-md mb-5">       
          <li className="list-row">
            <div><CgProfile className='ft-size24 text-gray-500' /></div>
            <div>
              <div><Link><h4 className='ft-size18 font-semibold'>Profile & Roles</h4></Link></div>
              <div className="text-xs font-semibold opacity-60">Role: Learning Comms Authorized Sender (read-only in shell).</div>
            </div>
          </li>
        </ul>

        <ul className="list bg-base-100 rounded-box shadow-md">
          <li className="p-4 pb-2 text-xs tracking-wide">
            <h4 className='ft-size18 font-semibold'>Training</h4>
          </li>
          
          <li className="list-row">
            <div><GoVideo className='ft-size18 text-gray-500' /></div>
            <div>
              <div><Link>How to build an email template</Link></div>
              <div className="text-xs font-semibold opacity-60">Email building</div>
            </div>
            <Link className="btn btn-square">
              <FaArrowRight className='ft-size18' />
            </Link>
          </li>
          
          <li className="list-row">
            <div><GrDocumentText className='ft-size18 text-gray-500' /></div>
            <div>
              <div><Link>How to work with the Audience Segmentation report </Link></div>
              <div className="text-xs font-semibold opacity-60">Reporting</div>
            </div>
            <Link className="btn btn-square">
              <FaArrowRight className='ft-size18' />
            </Link>
          </li>

          <li className="list-row">
            <div><GoVideo className='ft-size18 text-gray-500' /></div>
            <div>
              <div><Link>How to request a new email template</Link></div>
              <div className="text-xs font-semibold opacity-60">Email building</div>
            </div>
            <Link className="btn btn-square">
              <FaArrowRight className='ft-size18' />
            </Link>
          </li>

          <li className="list-row">
            <div><GrDocumentText className='ft-size18 text-gray-500' /></div>
            <div>
              <div><Link>How to create a new campaign</Link></div>
              <div className="text-xs font-semibold opacity-60">Campaigns</div>
            </div>
            <Link className="btn btn-square">
              <FaArrowRight className='ft-size18' />
            </Link>
          </li>
          
        </ul>
      </div>
      <div>
        <h3 className='ft-size18 font-semibold mb-2'>Need support?</h3>
        <p className='mb-3'>File a ticket or chat with the ops team.</p>
        <button className='btn shadow-sm shadow-gray-500/50 btn-magenta'>Request support</button>
      </div>
    </div>
    </>
  )
}

export default Settings
