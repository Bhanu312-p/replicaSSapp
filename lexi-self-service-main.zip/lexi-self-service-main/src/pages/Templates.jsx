import React, { useState } from 'react'
import { Form, Link } from 'react-router-dom'
import { InputCheckbox, InputSearch, InputSelect, InputToggle } from '../components'
import { MdContentPasteSearch, MdOutlineEmail } from 'react-icons/md'
import { BsSpeedometer} from 'react-icons/bs'
import { IoKeyOutline } from 'react-icons/io5'

const templatesData = [
  {
    id: "TM-1001",
    title: "Manager Essentials – Launch (Email)",
    sendAsAlias: "Learner Experiences <lexi@microsoft.com>",
    emailType: "Announcement",
    emailSubtype: "Program launch",
    owner: "Gabe Long",
    lastUsed: "2025-10-29T12:34:00Z",
    campaignsUsing: 4,
  },
  {
    id: "TM-1002",
    title: "Security Compliance – Reminder 1",
    sendAsAlias: "Security Awareness <sec@microsoft.com>",
    emailType: "Reminder",
    emailSubtype: "Follow-up",
    owner: "Priya Desai",
    lastUsed: "2025-10-30T09:10:00Z",
    campaignsUsing: 6,
  },
  {
    id: "TM-1003",
    title: "Skilling Month-in-Review",
    sendAsAlias: "Skilling Programs <skills@microsoft.com>",
    emailType: "Education",
    emailSubtype: "Newsletter",
    owner: "Jenna Park",
    lastUsed: "2025-10-20T15:02:00Z",
    campaignsUsing: 3,
  },
  {
    id: "TM-1004",
    title: "AI Sales Play – Action Required",
    sendAsAlias: "Sales Enablement <sales-play@microsoft.com>",
    emailType: "Task / Action",
    emailSubtype: "Deadline reminder",
    owner: "Marco Alvarez",
    lastUsed: "2025-10-30T17:25:00Z",
    campaignsUsing: 2,
  },
  {
    id: "TM-1005",
    title: "Security Champions – Welcome",
    sendAsAlias: "Security Awareness <sec@microsoft.com>",
    emailType: "Announcement",
    emailSubtype: "FYI",
    owner: "Priya Desai",
    lastUsed: "2025-10-18T13:32:00Z",
    campaignsUsing: 1,
  },
]

const emailTypes = ['All email types', 'Announcement', 'Reminder', 'Education', 'Tast/Action']
const emailSubtypes = ['All subtypes', 'Program launch', 'Follow up', 'Deadline reminder', 'FYI', 'Newsletter']

const usageOptions = [
  { id: 'all', label: 'All' },
  { id: 'frequent', label: 'Frequently used' },
  { id: 'light', label: 'Light usage' },
  { id: 'never', label: 'Not yet used' },
];

const Templates = () => {
  const [selectedUsage, setSelectedUsage] = useState('all');
  const baseBtn = 'rounded-full cursor-pointer px-3 py-1 ft-size12 font-medium transition focus:outline-none focus:ring focus:ring-blue-300';
  const passive = 'bg-gray-100 cursor-pointer text-gray-700 hover:bg-gray-200';
  const active = 'bg-purple cursor-pointer text-white shadow hover:bg-blue-700';
  return (
    <>
    <div className='md:flex justify-between items-center pb-2 text-xs mb-5'>
      <div className="">
        <h2 className='ft-size24 font-semibold mb-1'>Templates</h2>
        <p>Approved email templates only. Use these for campaigns that require a reviewed and consistent learner experience.</p>
      </div>
      <button className='md:text-end btn shadow-sm shadow-gray-500/50 btn-magenta'>Request new template</button>
    </div>

    <div className='bg-base-100 rounded-box shadow-md mb-5'>
      <Form method='get' className='p-4'>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 justify-between items-end mb-2">
          <div>
            <InputSearch text='Search' name='search' placeholder='Search...' Icon={MdContentPasteSearch} />
          </div>
          <InputSelect text='Email type' name='emailType' list={emailTypes} Icon={MdOutlineEmail} />
          <InputSelect text='Email subtype' name='emailSubtype' list={emailSubtypes} Icon={MdOutlineEmail}/>
        </div>

        <div className="flex gap-5 items-end">
          <div className="">
            <div className="label">
              <BsSpeedometer className='text-gray-500' />
              <span className={`label-text ft-size14 text-gray-700 font-semibold`}>Usage frequency</span>
            </div>
            <div>
            {usageOptions.map(opt => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setSelectedUsage(opt.id)}
                className={`${baseBtn} ${selectedUsage === opt.id ? active : passive}`}
              >
                {opt.label}
              </button>
            ))}
            </div>
          </div>

          <div className=''>
            <div className="label">
              <IoKeyOutline className='text-gray-500' />
              <span className={`label-text ft-size14 text-gray-700 font-semibold`}>Ownership</span>
            </div>
            <InputToggle className='font-normal' text='Only show my templates' name='myTemplates' />
          </div>
          
          <div className="flex gap-2 ml-auto">
            <button type="button" className="btn shadow-sm shadow-gray-500/50 btn-purple">
              Apply filters
            </button>
            <button type="button" className="btn btn-ghost">
              Reset
            </button>
          </div>
        </div>

          {/* Hidden field so selection is submitted with the form */}
          <input type="hidden" name="usage" value={selectedUsage} />
      </Form>
    </div>

    <div className='bg-base-100 rounded-box shadow-md p-4 mb-5'>
      <div className="overflow-x-auto w-auto max-w-full">
        <table className="table table-zebra table-auto min-w-full">
          {/* head */}
          <thead>
            <tr className='bg-lightest-purple'>
              <th>ID</th>
              <th>Title</th>
              <th>Send-as alias</th>
              <th>Email type</th>
              <th>Email subtype</th>
              <th>Owner</th>
              <th>Last used</th>
              <th>Used in campaigns</th>
            </tr>
          </thead>
          <tbody>
            {
              templatesData.map(rowData => {
                const {id, title, sendAsAlias, emailType, emailSubtype, owner, lastUsed, campaignsUsing} = rowData
                return (
                <tr key={id}>
                  <td>{id}</td>
                  <td className='font-semibold'><Link className='hover:underline'>{title}</Link></td>
                  <td>{sendAsAlias}</td>
                  <td>{emailType}</td>
                  <td>{emailSubtype}</td>
                  <td>{owner}</td>
                  <td>{lastUsed}</td>
                  <td>{campaignsUsing}</td>
                </tr>
                )
              })
            }
          </tbody>
        </table>
      </div>
    </div>
    </>
  )
}

export default Templates
